package com.cg.wrapper;

public class intvalueDemo {
	public static void main(String[] args) 
    { 
  
        Integer intobject = new Integer("68"); 
  
        // Returns the value of this Integer as an int 
        int i = intobject.intValue(); 
        System.out.println("The integer Value of i = " + i);
        
        Integer intobject1 = new Integer(-76); 
        
        // Returns the value of this Integer as an int 
        int j = intobject1.intValue(); 
        System.out.println("The integer Value of j = " + j); 
    } 

}
