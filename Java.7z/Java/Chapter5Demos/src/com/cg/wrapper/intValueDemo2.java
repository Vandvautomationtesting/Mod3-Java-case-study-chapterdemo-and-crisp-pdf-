package com.cg.wrapper;

public class intValueDemo2 {
	public static void main(String[] args) 
    { 
  
        Integer intobject = new Integer((int) 98.22); 
  
        int i = intobject.intValue(); 
        System.out.println("The integer Value of i = " + i); 
  
        Integer intobject1 = new Integer("52"); 
  
        int i = intobject1.intValue(); 
        System.out.println("The integer Value of i = " + i); 
    } 

}
