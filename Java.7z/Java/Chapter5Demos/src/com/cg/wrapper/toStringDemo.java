package com.cg.wrapper;

public class toStringDemo {
	public static void main(String[] args) {

		   Integer i = new Integer(10);
		   
		      // returns a string representation of the specified integer with radix 10
		      String retval = i.toString(30, 10);
		      System.out.println("Value = " + retval);
		 
		      // returns a string representation of the specified integer with radix 16
		      retval = i.toString(30, 16);
		      System.out.println("Value = " + retval);

		      // returns a string representation of the specified integer with radix 8
		      retval = i.toString(30, 8);
		      System.out.println("Value = " + retval);
		   }


}
