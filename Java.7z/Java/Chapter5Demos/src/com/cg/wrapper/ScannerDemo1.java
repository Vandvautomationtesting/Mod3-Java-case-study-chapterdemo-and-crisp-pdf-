package com.cg.wrapper;

import java.util.Scanner;

public class ScannerDemo1 {
	   public static void main(String[] args) {

	      String s = "Hello World! 3 + 3.0 = 6  true";

	      // create a new scanner with the specified String Object
	      Scanner scanner = new Scanner(s);

	      // find the next Byte token and print it
	      // loop for the whole scanner
	      while (scanner.hasNext()) {

	         // if the next is byte, print found and the byte
	         if (scanner.hasNextByte()) {
	            System.out.println("Found :" + scanner.nextByte());
	         }

	         // if a Byte is not found, print "Not Found" and the token
	         System.out.println("Not Found :" + scanner.next());
	      }

	      // close the scanner
	      scanner.close();
	   }
}
