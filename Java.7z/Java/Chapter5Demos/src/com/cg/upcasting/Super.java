package com.cg.upcasting;
//upCastingDemo
class Super {
	   void Sample() {
	      System.out.println("method of super class");
	   }
	}
 class Sub extends Super {
	   void Sample() {
	      System.out.println("method of sub class");
	   }
	   
	   void Sample2(){
		   System.out.println("Method of Subclass");
	   }
	   
	   public static void main(String args[]) {
	      
		   //Sub obj1 = new Sub();
		  // obj1.Sample();
		  // Super obj =(Super)obj1; 
	     // obj.Sample();
		   Super obj2 = new Sub();
		   obj2.Sample();
		   Sub a=(Sub)obj2;
		   a.Sample2();
	      
	   }
	}
	