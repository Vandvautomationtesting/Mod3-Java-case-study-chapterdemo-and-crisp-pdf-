package com.cg.string;

public class StringDemo {

	   public static void main(String args[]) {
	      String palindrome = "Wellcome to Cg";
	      int len = palindrome.length();
	      System.out.println( "String Length is : " + len );
	   }
	}