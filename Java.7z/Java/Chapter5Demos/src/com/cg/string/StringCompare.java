package com.cg.string;

//The equals() method compares the characters inside a String object. The = =  operator compare  two object references to see whether they refer to the same instance. The program above shows the difference between the two.


class StringCompare {
	   public static void main(String args[]) {
	         String s1 = "Hello";
	         String s2 = new String(s1);

	         System.out.println(s1 + " equals " + s2 + " -> " +  
	                       s1.equals(s2));
	         System.out.println(s1 + " == " + s2 + " -> " + (s1 == s2));
	   }
	}

