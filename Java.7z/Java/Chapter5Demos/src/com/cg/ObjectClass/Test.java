package com.cg.ObjectClass;
//import java.io.*;
//hashCode method demo:Returns hashCode of the invoking object
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 String Str = new String("Welcome to Capgemini.com");
	      System.out.println("Hashcode for Str :" + Str.hashCode() );

	}

}
