package annotationOverride;

class ParentClass
{
	public void displayMethod(String msg){
		System.out.println(msg);
	}
}

