package com.cg.polymorph;

//Program for Method Overloading in Java

class Mltply {
	 void mul(int a, int b) {
	  System.out.println("Sum of two=" + (a * b));
	 }

	 void mul(int a, int b, int c) {
	  System.out.println("Sum of three=" + (a * b * c));
	 }
	}
	