package com.cg.superKeyword;

public class Test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s = new Student(); 
	}

}
